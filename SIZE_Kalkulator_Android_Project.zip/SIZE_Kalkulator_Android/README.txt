SIZE KALKULATOR — Proyek Android

Isi:
- app/src/main/assets/index.html : kalkulator SIZE
- MainActivity.kt : aplikasi Android WebView
- Gradle build files

PENTING:
Ini adalah proyek sumber Android, bukan APK yang sudah dikompilasi. Lingkungan pembuatan ini tidak memiliki Android SDK/Gradle yang diperlukan untuk menghasilkan APK langsung.

Cara membangun APK:
1. Instal Android Studio di komputer.
2. Buka Android Studio > Open, pilih folder SIZE_Kalkulator_Android.
3. Tunggu Gradle Sync selesai dan izinkan Android Studio memasang komponen SDK yang diminta.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Setelah selesai, klik Locate untuk menemukan app-debug.apk.
6. Pindahkan APK ke HP Android dan instal. Jika diminta, izinkan instalasi dari sumber tersebut.

Aplikasi bekerja offline karena halaman kalkulator disimpan di dalam aplikasi.
